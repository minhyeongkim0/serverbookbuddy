package com.example.bookbuddyproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookbuddyprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookbuddyprojectApplication.class, args);
    }

}
